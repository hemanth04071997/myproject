package com.DAO;

import javax.persistence.EntityManager;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student s=new Student();
  s.setId(45);
  s.setName("sastry");
 
  StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
  MetadataSources metadata=new MetadataSources(registry);
  Metadata meta =metadata.getMetadataBuilder().build();
  SessionFactory sessionFactory = meta.getSessionFactoryBuilder().build();
   
  Session session = sessionFactory.openSession();
Transaction tr=session.beginTransaction();
	session.save(s);
	tr.commit();
	
  }
	}


